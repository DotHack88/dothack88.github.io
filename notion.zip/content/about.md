## This is Paul's Notion portfolio

I am Paul, open-source dev. I create apps and websites for start-ups, solopreneurs, corporations and local businesses. I truly enjoy helping businesses achieve their goals by delivering an exceptional websites and apps that communicates their business value to their target audience.

Here's take this free SaaS template for you [This is a link](https://saasy-dark.netlify.app/)


### Also please have a look at this beautiful picture

![this is an image](./assets/images/home/forest.jpg)

Truly marvelous!

> what about this note

* This is a bullet point I want.
* This is another bullet point.

1. This is number


```py
from universe import earth

show(earth.get("paul"))
```