## My experiences

I have many experiences including

1. Apple - (2005 - 2008)
2. IBM - (2009 - 2012)
3. Meta AI - (2015 - 2020)